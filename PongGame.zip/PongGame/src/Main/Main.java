
package Main;

import java.awt.FontFormatException;
import java.io.IOException;
import pong.Ventana;

public class Main {

    public static void main(String[] args) throws FontFormatException, IOException {
        Ventana v=new Ventana();
        v.setVisible(true);
    }
    
}
