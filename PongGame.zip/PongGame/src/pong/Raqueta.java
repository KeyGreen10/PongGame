
package pong;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;

public class Raqueta extends JPanel{
    private int x, y, ancho, alto,goles;
    public Raqueta(int raqueta,Rectangle limites){
        int maximoY= (int) limites.getMaxY();
        int minimoY= (int) limites.getMinY();
        int maximoX= (int) limites.getMaxX();
        int minimoX= (int) limites.getMinX();
        ancho=15;
        alto=75;
        if(raqueta==1){
            this.x=maximoX/6;
        }else{
            if(raqueta==2){
                this.x=maximoX-(maximoX/6);
            }
        }
        
        this.y=(maximoY/2)-50;
        
        goles=0;
    }
    
    public void iniRaqueta(){
        setBackground(Color.WHITE);
        setSize(ancho,alto);
        setLocation(x,y);
        repaint();
    }
    
    public void moverR1(Rectangle limites){
        
        iniRaqueta();
        if(Controles.w&&y>limites.getMinY()){
            y--;
        }
        
        if(Controles.s&&y<limites.getMaxY()-75){
            y++;
        }
    }
    
    public void moverR2(Rectangle limites){
        
        iniRaqueta();
        if(Controles.up&&y>limites.getMinY()){
            y--;
        }
        
        if(Controles.down&&y<limites.getMaxY()-75){
            y++;
        }
    }
    
    public void gol(){
        goles++;
    }
    
    public int getGol(){
        return goles;
    }
}
