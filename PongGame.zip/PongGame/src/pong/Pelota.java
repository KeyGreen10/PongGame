
package pong;

import java.awt.Color;
import java.awt.Rectangle;
import javax.swing.JPanel;

public class Pelota extends JPanel{
    int x;
    int y;
    int dx=1,dy=1;
    boolean gana;
    boolean colision1, colision2;
    public Pelota(){
        this.x=400;
        this.y=250;
        iniPelota();
        colision1=false;
        colision2=false;
    }
    
    public void iniPelota(){
        setSize(10,10);
        setBackground(Color.WHITE);
        setLocation(400,250);
    }
    
    public void mover(Rectangle limite, Rectangle r1, Rectangle r2){
        iniPelota();
        x=x+dx;
        y=y+dy;
        
        if(gana==true&&x==400&&y==250){
            dx=-dx;
        }
        
        if(colision1){
            dx=-dx;
            x=(int) r1.getLocation().x+15;//sumar ancho a la pos y luego 10
            colision1=false;
        }
        
        if(colision2){
            dx=-dx;
            x=(int) r2.getLocation().x-10;
            colision2=false;
        }
        
        if(x>limite.getMaxX()-10){
            dx=-dx;
        }
        
        if(y>limite.getMaxY()-10){
            dy=-dy;
        }
        
        if(x<0){
            dx=-dx;
        }
        
        if(y<0){
            dy=-dy;
        }
        setLocation(x,y);
    }
    
    public void setGanador(int ganador){
        if(ganador==1){
            gana=false;
        }else{
            if(ganador==2){
                gana=true;
            }
        }
    }
}
