
package pong;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Controles extends KeyAdapter {
    
    static boolean w,s,up,down;
    
    @Override
    public void keyPressed(KeyEvent evt){
        
        int tecla=evt.getKeyCode();
        
        if(tecla==87||tecla==119){
            w=true;
        }
        
        if(tecla==83||tecla==115){
            s=true;
        }
        
        if(tecla==KeyEvent.VK_UP){
            up=true;
        }
        
        if(tecla==KeyEvent.VK_DOWN){
            down=true;
        }
    }
    
    @Override
    public void keyReleased(KeyEvent evt){
        int tecla=evt.getKeyCode();
        
        if(tecla==87||tecla==119){
            w=false;
        }
        
        if(tecla==83||tecla==115){
            s=false;
        }
        
        if(tecla==KeyEvent.VK_UP){
            up=false;
        }
        
        if(tecla==KeyEvent.VK_DOWN){
            down=false;
        }
    }
}
