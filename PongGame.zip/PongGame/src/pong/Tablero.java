
package pong;

import java.awt.Color;
import java.awt.FontFormatException;
import java.io.IOException;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Tablero extends JPanel{
    Pelota pelota;
    Raqueta r1;
    Raqueta r2;
    Puntuacion puntuacion;
    JPanel raya;
    public Tablero() throws FontFormatException, IOException{
        setSize(800,500);
        setBackground(Color.BLACK);
        pelota=new Pelota();
        add(pelota);
        r1=new Raqueta(1,getBounds());
        r2=new Raqueta(2,getBounds());
        add(r1);
        add(r2);
        puntuacion=new Puntuacion(r1,r2,getBounds());
        add(puntuacion.getMarcador1());
        add(puntuacion.getMarcador2());
        raya=new JPanel();
        
    }
    
    public void actualizar(){
        colision();
        marcar();
        pelota.mover(getBounds(),r1.getBounds(),r2.getBounds());
        r1.moverR1(getBounds());
        r2.moverR2(getBounds());
        puntuacion.iniPuntuacion(getBounds());
        raya.setBackground(Color.WHITE);
        raya.setLocation((int)getBounds().getCenterX(),0);
        raya.setSize(2,500);
        add(raya);
    }
    
    public void colision(){
        if(pelota.getBounds().intersects(r1.getBounds())){
            pelota.colision1=true;
        }
        
        if(pelota.getBounds().intersects(r2.getBounds())){
            pelota.colision2=true;
        }
    }
    
    public boolean marcar(){
        
        if(pelota.x+pelota.getBounds().height==getBounds().getMaxX()){
            r1.gol();
            pelota.setGanador(1);
            pelota.x=400;
            pelota.y=250;
        }else{
            if(pelota.x==getBounds().getMinX()){
                r2.gol();
                pelota.setGanador(2);
                pelota.x=400;
                pelota.y=250;
            }
        }
        return true;
    }
}
