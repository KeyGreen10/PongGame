
package pong;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import javax.swing.JLabel;


public class Puntuacion{
    int p1;
    int p2;
    JLabel marcador1;
    File fuenteF;
    Font fuente;
    Font ffuente;
    JLabel marcador2;
    Raqueta r1;
    Raqueta r2;
    public Puntuacion(Raqueta r1, Raqueta r2, Rectangle limites) throws FontFormatException, IOException{
        p1=0;
        p2=0;
        marcador1=new JLabel();
        marcador2=new JLabel();
        fuenteF=new File("C:/Users/josem/AppData/Local/Microsoft/Windows/Fonts/DS-DIGIB.TTF");
        fuente=Font.createFont(Font.TRUETYPE_FONT, fuenteF);
        GraphicsEnvironment ge= GraphicsEnvironment.getLocalGraphicsEnvironment();
        ge.registerFont(fuente);
        ffuente=new Font(fuente.getName(),Font.BOLD,50);
        this.r1=r1;
        this.r2=r2;
        iniPuntuacion(limites);
    }
    
    public void iniPuntuacion(Rectangle limites){
        marcador1.setForeground(Color.WHITE);
        marcador1.setVisible(true);
        marcador1.setLocation((int)limites.getMaxX()/3,(int) limites.getMaxY()/8);
        marcador1.setSize(70, 70);
        marcador1.setFont(ffuente);
        marcador1.setText(String.valueOf(r1.getGol()));
        marcador2.setForeground(Color.WHITE);
        marcador2.setVisible(true);
        marcador2.setLocation((int) ((int)limites.getMaxX()-limites.getMaxX()/3),(int) limites.getMaxY()/8);
        marcador2.setSize(70, 70);
        marcador2.setFont(ffuente);
        marcador2.setText(String.valueOf(r2.getGol()));
    }
    
    public JLabel getMarcador1(){
        return marcador1;
    }
    
    public JLabel getMarcador2(){
        return marcador2;
    }
}
